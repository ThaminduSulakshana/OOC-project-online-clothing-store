#include "Sales_Records.h"

//Sales records class
void addOrders(Order* ord1){}
Sales_Records::Sales_Records(){}
Sales_Records::Sales_Records(int transID)
{
	transaction_ID = transID;
}

void Sales_Records::itemtransaction(){}
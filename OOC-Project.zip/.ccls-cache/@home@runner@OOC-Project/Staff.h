//Declaration of staff class
class Staff
{
	private:
		int staff_ID;
		char staff_Name[];

	public:
		Staff();
		Staff(int sid, char sname[]);
		void notify();

};
#include "Cash.h"
//Cash class

Cash::Cash(){}
Cash::Cash(float cash_amt)
{
	amount = cash_amt;
}
#include "Order.h"
//Order Class

Order::Order(){}
Order::Order(int oid, int oqty)
{
	order_ID = oid;
	quantity = oqty;
}
void Order:: verifypayment(){}

void additems(Clothes* cl1){}
void addStaff(Staff* st1){}

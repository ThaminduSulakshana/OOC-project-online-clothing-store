#include "Payment.h"

//Payment Class
Payment::Payment(){}
Payment::Payment(int pid, float pamount)
{
	payment_id = pid;
	amount = pamount;
}
void Payment::verify_payment(){}
